<?php 
    //Definimos parametros de la bbdd
 define("SERVIDOR","localhost");
 define("USUARIO","id17875467_root");
 define("PASSWORD","=!lJ}zP&PQz[|q8=");
 define("BD","id17875467_db2_abp");
