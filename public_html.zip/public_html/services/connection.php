<?php
$servername = "localhost";
$username = "id17875467_root";
$password = "=!lJ}zP&PQz[|q8=";
$database = "id17875467_db2_abp";
 
 try {
    $pdo = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
    // set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch(PDOException $e) {    
    echo "Connection failed: " . $e->getMessage();
    }
?>