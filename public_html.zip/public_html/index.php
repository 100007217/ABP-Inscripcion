<?php
header ("Location: view/home.php");
?>