


<html>

<head>
  <link rel="stylesheet" href="css/style.css">
  <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="../css/login.css">
  <title>Login</title>
</head>

<body>
  <div class="main">
    <p class="sign" align="center">Inicia Sesión</p>
    <form class="form1" action="../processes/login.proc.php" method="post">
      <input class="un " type="text" align="center" name="email" placeholder="Correo electrónico">
      <input class="submit" type="submit" value="Entrar">
            
                
    </div>
     
</body>

</html>